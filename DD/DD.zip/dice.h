#ifndef DICE_H
#define DICE_H

#include <QDialog>
#include <QtWidgets>
#include <QMainWindow>

namespace Ui {
class Dice;
}

class Dice : public QDialog
{
    Q_OBJECT




public:
    explicit Dice(QWidget *parent = nullptr);
    ~Dice();


    void onAddWidget();
    void onRemoveWidget();
    void onComboBoxChange();



    QString Text;
    int spinNum[20];
    int Fnumber;
    QStringList diceList;

private slots:
    void on_pushButton_clicked();

    void on_pushButton_2_clicked();

    void on_pushButton_Delete_clicked();

private:
    Ui::Dice *ui;
};

#endif // DICE_H
