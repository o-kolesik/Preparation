#include "dice.h"
#include "ui_dice.h"
#include <QPushButton>
#include <QComboBox>
QHash<QPushButton*, QHBoxLayout*> mButtonToLayoutMap;
Dice::Dice(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dice)
{

    ui->setupUi(this);

    QObject::connect(
         ui->pushButton, &QPushButton::clicked,
         this, &Dice::onAddWidget);
}

Dice::~Dice()
{
    delete ui;
}

void Dice::onAddWidget()
{

QVBoxLayout* layout = qobject_cast<QVBoxLayout*>(ui->widgets_frame->layout());

QHBoxLayout* newLayout = new QHBoxLayout();

QString buttonText = tr("Delete #%1").arg(layout->count());
    QPushButton* button = new QPushButton(buttonText);
    newLayout->addWidget(button);


    QComboBox* comboBox = new QComboBox();
    comboBox->addItem("-");
    comboBox->addItem("D4");
    comboBox->addItem("D6");
    comboBox->addItem("D8");
    comboBox->addItem("D10");
    comboBox->addItem("D100");
    comboBox->addItem("D12");
    comboBox->addItem("D20");
    comboBox->addItem("+/-");
      newLayout->addWidget(comboBox);


    QSpinBox* spinBox = new QSpinBox();
    spinBox->setMinimum(-10);
    spinBox->setMaximum(10);
      newLayout->addWidget(spinBox);

       layout->insertLayout(0, newLayout);

        mButtonToLayoutMap.insert(button, newLayout);

        QObject::connect(button, &QPushButton::clicked, this, &Dice::onRemoveWidget);
        QObject::connect(comboBox, &QComboBox::currentIndexChanged, this, &Dice::onComboBoxChange);
        QObject::connect(spinBox, &QSpinBox::valueChanged, this, &Dice::onComboBoxChange);


//ui->plainTextEdit->setT
}

void Dice::onRemoveWidget()
{

    QPushButton* button = qobject_cast<QPushButton*>(sender());
    QHBoxLayout* layout = mButtonToLayoutMap.take(button);

    while (layout->count() != 0) {
        QLayoutItem* item = layout->takeAt(0);
        delete item->widget();
        delete item;
    }
    delete layout;

}

void Dice::onComboBoxChange()
{

    QComboBox* comboBox=  qobject_cast<QComboBox*>(sender());
   // QSpinBox* spinBox=  qobject_cast<QSpinBox*>(sender());
    QVBoxLayout* layout = qobject_cast<QVBoxLayout*>(ui->widgets_frame->layout());


   // Fnumber=layout->count()-1;
  //  Dnumber=spinBox->value();

    Text+= comboBox->currentText()+"\n";
//diceList[0]=comboBox->currentText();

}

void Dice::on_pushButton_clicked()
{
    //onAddWidget();
}


void Dice::on_pushButton_2_clicked()
{
    QVBoxLayout* layout = qobject_cast<QVBoxLayout*>(ui->widgets_frame->layout());
   Text+= "----------------\n";
   ui->textEdit->setText(QString(Text));
  //  ui->textEdit->setText(QString::number(layout->count()));
/*QString nText;
for (int i = 0; i < diceList.size(); ++i){
    nText+=diceList[i]+"\n";
}
nText+= "----------------\n";
ui->textEdit->setText(QString(nText));*/


}



void Dice::on_pushButton_Delete_clicked()
{
    QVBoxLayout* layout = qobject_cast<QVBoxLayout*>(ui->widgets_frame->layout());

    QHBoxLayout* layout2 = qobject_cast<QHBoxLayout*>(ui->widgets_frame->layout());

    delete layout2;


}

